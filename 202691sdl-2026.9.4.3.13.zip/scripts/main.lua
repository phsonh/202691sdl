modules.Frame.SetFrameFunc(
    function()
        modules.Window.SetTitle("Frame running")
    end
)